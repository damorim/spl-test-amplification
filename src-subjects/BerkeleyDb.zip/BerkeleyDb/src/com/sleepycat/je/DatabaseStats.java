//#if STATISTICS
package com.sleepycat.je;
import java.io.Serializable;
/** 
 * Javadoc for this public class is generated
 * via the doc templates in the doc_src directory.
 */
public abstract class DatabaseStats implements Serializable {
  protected DatabaseStats(){
  }
}
//#endif
