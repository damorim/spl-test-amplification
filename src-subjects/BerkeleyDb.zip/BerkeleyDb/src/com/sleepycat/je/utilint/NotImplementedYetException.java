package com.sleepycat.je.utilint;
/** 
 * Something is not yet implemented.
 */
public class NotImplementedYetException extends RuntimeException {
  public NotImplementedYetException(){
    super();
  }
  public NotImplementedYetException(  String message){
    super(message);
  }
}
